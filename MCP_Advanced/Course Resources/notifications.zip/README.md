# MCP Logging and Progress Demo

A demonstration of the Model Context Protocol using a STDIO transport.

## Setup

Install dependencies using uv:

```bash
uv sync
```

## Running the Project

Run the MCP client:

```bash
uv run client.py
```

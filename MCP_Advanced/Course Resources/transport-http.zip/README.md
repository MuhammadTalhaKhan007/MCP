## Setup

Install dependencies using uv:

```bash
uv sync
```

## Running the Project

Run the MCP server:

```bash
uv run main.py
```
